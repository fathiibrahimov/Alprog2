#include "tp6.h"

int main(){//memanggil prosedur yang dibutuhkan
	masuk();
	gabung();
	cariaktif();
	cariurut();
	cetak();
	
	return 0;
}
/*Saya Ahmad Fathi Ibrahimov mengerjakan evaluasi Tugas Evaluasi 6 dalam mata kuliah
Algoritma dan Pemrograman II untuk keberkahanNya maka saya tidak
melakukan kecurangan seperti yang telah dispesifikasikan. Aamiin.*/